#Machine Learning Code
## Import libraries
import numpy as np
import pandas as pd
import sqlite3    ## SQL Interface

from sklearn.feature_extraction.text import CountVectorizer  ## BOW Model

from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
conn = sqlite3.connect('F_data.sqlite')  #Loading the sqlite file for future use
final = pd.read_sql_query("""SELECT * FROM Data""", conn)
conn.close()
final.drop(['Column1'],axis=1,inplace = True)
X=final.iloc[:,:9].values
y=final.iloc[:,9:].values
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3, shuffle = False) #Splitting X and Y as 70 % training and 30 % testing with shuffle set to false
# Values for the hyperparameter 'C':
tuned_params = [{'C': [0.0001,0.001,0.01,0.1,1,10,100,1000,10000]}]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3, shuffle = False)# Grid Search
model = GridSearchCV(LogisticRegression(), tuned_params, scoring = 'accuracy')
model.fit(X_train, y_train)
print(model.best_estimator_)
print(model.score(X_test, y_test))
clf = LogisticRegression(C = 0.01)
clf.fit(X_train, y_train)
